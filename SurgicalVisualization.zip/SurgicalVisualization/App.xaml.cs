using System.Windows;
namespace SurgicalVisualization
{
    public partial class App : Application { }
}